import json
from difflib import get_close_matches
data = json.load(open('data.json'))


def translate(word):
    check = get_close_matches(word, data.keys())
    try:
        return data[word]
    except KeyError:
        if word.title() in data.keys():
            return data[word.title()]
        elif word.upper() in data.keys():
            return data[word.upper()]
        elif len(check):
            yn = input(f'Did you mean {check[0]} ?')
            if yn == 'Y' or yn == 'y':
                return data[check[0]]
            elif yn == 'N' or yn == 'n':
                return "word not found"
            else:
                return 'We do not understand your query'

        else:
            return "word not found"

user_input = input('The word you want to search: ')
user_input= user_input.lower()

a = translate(user_input)

if type(a) == list:
    c = 1
    for i in a:
        print(str(c) + '.' + i)
        c += 1
else:
    print(a)
